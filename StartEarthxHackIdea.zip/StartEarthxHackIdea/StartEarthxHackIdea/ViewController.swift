//
//  ViewController.swift
//  StartEarthxHackIdea
//
//  Created by Ana Brendel on 4/24/20.
//  Copyright © 2020 Ana Brendel. All rights reserved.
//
//  Ideas for querying syntax from Tim Richardson (via medium article) [lines 32-39]
//

/* Notes:
        A lot of the variables used and methods of storing the information
        can and would be changed upon implementation. This is because
        State Farm users already have individualized accounts in the server,
        so State Farm wouldn't want to store the data in the app on the
        specific device. In this code wherever "UserDafaults" is used,
        State Farm would want to modify the values in their server that are
        associated with this user instead.
 
        Additionally for research purposes, State Farm might want to save
        values in, not only the user's accounts, but in a data base as well.
        This would help to not only augment this feature, but add to other
        projects and features of State Farm's platform as well. */

import UIKit
import CoreMotion

/* IMPORTANT DEVELOPER NOTE:
    There is no front end component for this application.
    This code simply shows a possible implementation of using
    the queryActivityStarting method from the Core Motion class
    to provide the percentage of time a user is in a moving
    vehicle for a given interval of time. Again upon implementation,
    this feature would be added to the State Farm's already existing
    application interface.
 
    Also note, the Info.plist file is also changed, such that upon
    launch the user is prompted to give the app permission to look
    at the motion data from the system. */

class ViewController: UIViewController {
    // called upon the app's launch
    override func viewDidLoad() {
        // call the super to ensure a important set up occurs
        super.viewDidLoad();
        // get the dates to query - starting with today
        let today = Date.init();
        // get the date from seven days ago - as the first check
        let lastDate1 = Calendar.current.date(byAdding: .day, value: -7, to: Date());
        // work to ensure that the date is in correct form/type
        var lastDate = today;
        if lastDate1 != nil{
            lastDate = lastDate1!;
        }
        // use to check if launched before - you might have a more recent date that was checked
        let appUsed = UserDefaults.standard.bool(forKey: "appUsed");
        if appUsed {
            let lastDateTimeInt = UserDefaults.standard.double(forKey: "lastUpdate");
            let lastDateSaved = Date.init(timeIntervalSinceReferenceDate: lastDateTimeInt);
            // if the last updated is within the past 7 days, you only need to look back to that day
            if lastDateSaved > lastDate{
                lastDate = lastDateSaved;
            }
        }
        // use the motion activity manager to query past data
        // store, for each time interval, if the phone/device was in a car
        let motionManager = CMMotionActivityManager();
        var motionValues = [Double]();
        motionValues.append(0.0); // to have non-null list, negligible affect on calculation
        // require motion data (i.e. from a mobile device) to produce interesting results
        motionManager.queryActivityStarting(from: lastDate, to: today, to: .main) { motionActivities, error in
            if let error = error {
                // this prints if there was a error in detection - would occur if no mobile data available
                print("error: \(error.localizedDescription)")
                return
            }
            // this part stores the time units spent in or not in an automobile
            motionActivities?.forEach { motion in
                if motion.automotive {
                    motionValues.append(1.0);
                } else {
                    motionValues.append(0.0);
                }
            }
        }
        // gather the number of intervals recorded and spent in moving vehicle
        var numUnits = 0.0;
        var numUnitsInCar = 0.0;
        for x in motionValues{
            numUnits += 1;
            numUnitsInCar += x;
        }
        // need to calculate the percentage of time spent in a moving car
        let percentageTimeInCar = numUnitsInCar/numUnits;
        
        // check if you need to set the default (i.e. you have no data yet)
        if UserDefaults.standard.double(forKey: "totalUnits") == 0.0{
            let averageStatistic = 0.15; // statistic from StateFarm or research
            UserDefaults.standard.set(-1.0,forKey: "totalUnits");
            UserDefaults.standard.set(averageStatistic,forKey: "normalTimeDriving");
        }
        
        // need to compare this to the average time spent in an automobile
        let avgPercentTimeInCar = UserDefaults.standard.double(forKey: "normalTimeDriving");
        let difference = avgPercentTimeInCar - percentageTimeInCar;
        
        print(difference); // --> printed for debug purposes
        /* IMPORTANT DEVELOPER NOTE:
                StateFarm would decided how to handle the difference value,
                we could: store the differences from a whole month to determine
                what the optimal discount based on comparison to prior months averages,
                or at a given moment could request the difference (which
                would be this value) and some how use that to calculate the discount,
                pull everyone's data to give a universal discount during
                this pandemic time (to give back to essential workers), just store
                the data for each user, etc. */
        
        // updates the average time in a moving vehicle (user specfic)
        modifyAverageDrivingTime(current: percentageTimeInCar, units: numUnits);
        
        // update the saved values - i.e. last time updated
        UserDefaults.standard.set(true, forKey: "appUsed");
        UserDefaults.standard.set(today.timeIntervalSinceReferenceDate, forKey: "lastUpdate");
        
    }
    
    /* this function helps to calculate what the new average frequency spent in the
        the car is for this given user */
    func modifyAverageDrivingTime(current: Double, units: Double){
        // get the current averages for the user
        let avgTime = UserDefaults.standard.double(forKey: "normalTimeDriving");
        let totalUnits = UserDefaults.standard.double(forKey: "totalUnits");
        // this is based on how StateFarm would want to modify the avg
        // maybe wait until the time hits the average again, to symbolize normal collection
        if totalUnits < 0 && avgTime <= current{
            // this means we just hit normal value for time "driving" -> so set new averages
            UserDefaults.standard.set(units,forKey: "totalUnits");
            UserDefaults.standard.set(current,forKey: "normalTimeDriving");
            
        } else if totalUnits > 0{
            // this means we have been in "normal collection"
            // so we just continue to modify the average that is already in place
            let newAvgTime = ((avgTime * totalUnits) + (current * units)) / (units + totalUnits);
            let newUnits = units + totalUnits;
            UserDefaults.standard.set(newUnits,forKey: "totalUnits");
            UserDefaults.standard.set(newAvgTime,forKey: "normalTimeDriving");
        }
        // else, we are still in "pandemic mode" so the average time in a car wouldn't be accurate to record
    }


}


